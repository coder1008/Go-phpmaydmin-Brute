Linux系统下用法:
参数说明:
-url			#phpmyadmin的完整网址,例如:http://example.com/phpmyadmin 或 https://example.com/phpmyadmin
-u user.txt 	#加载指定的用户名文件,不指定具体位置,则默认加载程序当前目录下的user.txt 
-p pass.txt 	#加载指定的口令文件,不指定具体位置,则默认加载程序当前目录下的user.txt
-o ok.txt		#指定爆破成功后,成功的数据写入的文件,可指定文件名也可以不指定文件(不指定默认会在程序运行目下生成success.txt)

用法1:
/* 运行前,账户字典user.txt 和 密码字典pass.txt 必须首先放在当前程序目录下 */
chmod -R 777 bf_phpmyadmin
./bf_phpmyadmin -h
./bf_phpmyadmin --url http://example.com/phpmyadmin/ -u user.txt -p pass.txt


用法2:
/* 指定加载的账户和密码字典位置在/home/目录下，爆破成功结果/home/ok.txt  */
chmod -R 777 bf_phpmyadmin
./bf_phpmyadmin -h
./bf_phpmyadmin --url http://example.com/phpmyadmin/ -u /home/user.txt -p /home/pass.txt -o /home/OK.txt